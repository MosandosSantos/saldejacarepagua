# Dashboard — código completo (export)

Código-fonte completo da página de dashboard do GPRBRCRM, extraído do projeto
em `dashboard/` + dependências em `core/`.

## Estrutura dos arquivos

```
dashboard/
├── __init__.py                    # Pacote do app Django
├── apps.py                        # Config do app
├── urls.py                        # Rotas: /  (index)  e  /dados/  (JSON auto-refresh)
├── views.py                       # Toda a lógica (710 linhas) — ver seção "Como funciona"
└── templates/dashboard/
    ├── index.html                 # Página principal (651 linhas): cards, gauge 3D, gráficos Chart.js
    └── partials/
        ├── _kpis.html             # 4 KPIs do topo (Lojas Ativas, Novos Membros, Sessões, Caixa)
        ├── _tarefas.html          # Alerta de tarefas atrasadas/hoje
        ├── _baii.html             # Funil 3D SVG: membros por grau (MX/EN/CBCS)
        ├── _melhores.html         # Card "Potência no Simbolismo" (chart horizontal)
        ├── _atividade.html        # Card "Tempo na Maçonaria" (chart horizontal)
        ├── _analise.html          # Ranking das Lojas (top 10 por membros)
        ├── _ranking_mx.html       # Ranking MX (lojas com mais mestres)
        ├── _proximas_sessoes.html # Próximas 6 sessões na agenda das lojas
        ├── _agendamento.html      # Tabela sessões realizadas × agendadas (com paginação JS)
        ├── _kpis_avancados.html   # vazio (legado)
        ├── _metas.html            # vazio (legado)
        ├── _recentes.html         # legado (não incluído no index atual)
        ├── _conversao.html        # legado
        ├── _funil.html            # legado
        └── _timeline.html         # legado

core/
├── gprb.py                        # Conexão PostgreSQL (psycopg3) + ~20 queries do banco saldogprb
├── gprb_read.py                   # Camada de leitura agregada usada pelo dashboard
└── templatetags/
    └── seguranca.py               # Filtro `|js` — serializa dados Python p/ <script> com escape XSS
```

## Rotas

| URL | View | Descrição |
|---|---|---|
| `/` | `dashboard.views.index` | Página completa do dashboard |
| `/dados/` | `dashboard.views.dados` | JSON leve para auto-refresh dos KPIs (polling 45s) |

(As URLs do app são incluídas no `urls.py` raiz do projeto.)

## Como funciona

1. **`views.py → index()`**: monta o contexto em 3 blocos:
   - KPIs internos (Django ORM): negócios, conversão, metas, tarefas;
   - KPIs do priorado (SQL no banco externo `saldogprb` via `core/gprb.py`):
     lojas ativas/total, membros ativos/total, novos membros do ano,
     anuidade paga, membros por rito/idade/potência/tempo, rankings, sessões;
   - SVGs gerados no servidor: funil 3D BAII (`_baii_svg`) e timeline (`_timeline_svg`).

2. **`index.html`**: estende `templates/base/basic.html`, carrega Chart.js
   (`static/js/vendor/chart.umd.min.js`) e renderiza 4 gráficos:
   - `chart-entradas` (linha, admissões 36 meses);
   - `chart-rito` (barras, rito no simbolismo);
   - `chart-idade` (barras, faixa etária);
   - `chart-potencia` / `chart-tempo-maconaria` (barras horizontais).
   - Gauge 3D da anuidade é SVG puro animado com `requestAnimationFrame`.

3. **Auto-refresh**: `index.html` faz `fetch('/dados/')` a cada 45s e atualiza
   os elementos `[data-kpi]`, `[data-kpi-bar]` e o gauge sem recarregar a página.

## Dependências necessárias para rodar em outro projeto

- Django 4/5, psycopg 3 (`pip install psycopg[binary]`), `bcrypt`
- Apps: `acesso` (login/filtros/tenant), `contatos`, `gestao`, `recepcao`,
  `tarefas` (modelos Negocio, Movimentacao, MetaVendedor, Inscricao,
  Pagamento, Tarefa, etapas do tenant)
- Variáveis de ambiente do banco GPRB:
  `GPRB_DB_HOST`, `GPRB_DB_PORT`, `GPRB_DB_NAME` (saldogprb),
  `GPRB_DB_USER`, `GPRB_DB_PASSWORD`, `GPRB_DB_SSLMODE` (opcional, default `prefer`),
  `GPRB_DB_TIMEOUT` (opcional, default 10)
- Static: `static/js/vendor/chart.umd.min.js` (Chart.js UMD)
- Templatetag `{% load seguranca %}` (incluído em `core/templatetags/`)

## Variáveis de contexto do `index()`

`kpis`, `chart_membros_labels`, `chart_membros_valores`, `anualidade`,
`timeline`, `timeline_svg`, `conversao`, `funil`, `funil_svg`, `recentes`,
`por_etapa`, `tarefas_alerta`, `ticket_medio`, `por_origem`, `por_segmento`,
`melhores`, `atividade`, `velocidade`, `metas_dashboard`, `atualizado_em`,
`baii_ativos(_svg/_total)`, `baii_ano(_svg/_total/_ano)`, `ano_corrente`,
`ano_anuidade`, `rito_dados`, `idade_dados`, `potencia_dados`,
`tempo_maconaria_dados`, `ranking_lojas_dados`, `ranking_mx_dados`,
`proximas_sessoes_dados`, `agendamento_dados`.
